"""On ${date} at ${time} the ${nameAndExt} was created by ${user}"""
class ${name}:
    """TODO: Remove comment"""