package nbcookbookhg;

public class Car {
    String model;
    String plate;
    int year;
    int price;
    String color;
}
