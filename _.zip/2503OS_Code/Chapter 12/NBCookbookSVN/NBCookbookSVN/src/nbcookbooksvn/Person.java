package nbcookbooksvn;

public class Person {

}
