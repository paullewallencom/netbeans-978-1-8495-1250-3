package interfaceextraction;

public class Person {
    //code 
}
