package superclassextraction;

import java.util.ArrayList;

public class DataAnalyzer extends Analyzer {

    public void saveData() {
        //code
    }



    public String analyzeData(ArrayList<String> data, int offset) {
        //code
        return "";
    }
}
